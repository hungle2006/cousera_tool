(() => {
'use strict';
if (globalThis.__courseraAutoVideoInitialized) return;
globalThis.__courseraAutoVideoInitialized = true;

const topFrame = window === window.top;
const DELAY_AFTER_END_MS = 1400;
const RATE_RETRY_LIMIT = 12;
const RATE_RETRY_INTERVAL_MS = 1200; // Tránh can thiệp liên tục nếu player kiểm soát tốc độ
let state = null;
let watchVideo = null;
let urlSeen = location.href;
let endedInFlight = false;
let scanTimer = null;
let autoplayAttempted = new WeakSet();
let overlay = null;
let lastPlaybackReport = 0;
let lastStatePull = 0;
let rateFixAttempts = 0;
let lastRateFix = 0;
let rateWarningShown = false;
const observerCallbacks = new WeakMap();

function courseSlug() {
    const m = location.pathname.match(/^\/learn\/([\w-]+)(?:\/|$)/);
    return m ? m[1] : null;
}
function lectureInfo(url) {
    try {
        const p = new URL(url, location.href);
        const m = p.pathname.match(/^\/learn\/([\w-]+)\/lecture\/([\w-]+)(?:\/|$)/);
        if (p.protocol !== 'https:' || !/(^|\.)coursera\.org$/i.test(p.hostname) || !m) return null;
        return { slug: m[1], id: m[2], url: p.origin + p.pathname };
    } catch (_) { return null; }
}
function send(action, payload = {}) {
    return new Promise((resolve, reject) => {
        try {
            chrome.runtime.sendMessage({ action, ...payload }, response => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!response?.ok) return reject(new Error(response?.error || 'Lỗi kết nối tiện ích.'));
                resolve(response);
            });
        } catch (e) { reject(e); }
    });
}
function setMessage(message) {
    if (!state || state.status !== 'running') return;
    const el = overlay?.getElementById('av-status');
    if (el) el.textContent = message;
}
function fmtTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
    seconds = Math.floor(seconds);
    const m = Math.floor(seconds / 60), sec = String(seconds % 60).padStart(2, '0');
    return m >= 60 ? `${Math.floor(m/60)}:${String(m%60).padStart(2,'0')}:${sec}` : `${String(m).padStart(2,'0')}:${sec}`;
}
function renderPlayback(playback) {
    if (!topFrame || !overlay) return;
    const current = Number(playback?.currentTime || 0), duration = Number(playback?.duration || 0);
    const pct = duration > 0 ? Math.min(100, Math.round(current / duration * 100)) : 0;
    overlay.getElementById('av-playtime').textContent = `${fmtTime(current)} / ${fmtTime(duration)}`;
    overlay.getElementById('av-video-bar').style.width = `${pct}%`;
    overlay.getElementById('av-real-speed').textContent = playback?.rate ? `${playback.rate}× thực tế` : '—';
}
function createOverlay() {
    if (!topFrame || overlay) return;
    const host = document.createElement('div');
    host.id = 'coursera-auto-video-host';
    host.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:2147483600;';
    overlay = host.attachShadow({ mode: 'open' });
    overlay.innerHTML = `
      <style>
        :host{all:initial}*{box-sizing:border-box}[hidden]{display:none!important}
        .card{font:12px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;width:295px;background:#fff;color:#141414;border:1px solid #bbb;box-shadow:0 12px 36px #0003;border-radius:14px;padding:13px}
        .top{display:flex;justify-content:space-between;align-items:center;gap:8px;font-weight:800;letter-spacing:.3px}
        .tag{font-size:10px;color:#111;background:#eee;border:1px solid #ddd;border-radius:6px;padding:3px 7px;font-weight:700}
        .title{margin:11px 0 8px;font-weight:750;line-height:1.35;max-height:38px;overflow:hidden;overflow-wrap:anywhere}
        .muted{font-size:11px;color:#666}.rail{height:7px;border-radius:8px;background:#eee;overflow:hidden;margin:8px 0}
        .rail.thin{height:5px;margin:6px 0 9px}.bar{height:100%;width:0%;background:#111;transition:width .25s}
        .row{display:flex;align-items:center;justify-content:space-between;gap:8px}
        button{background:#111;color:#fff;border:1px solid #111;border-radius:8px;padding:7px 9px;cursor:pointer;font-weight:700}
        button:disabled{opacity:.4;cursor:default}
        button.light{background:white;color:#111}
        #av-min{font-size:12px;padding:3px 8px;background:transparent;color:#111;border:1px solid #ddd}
        .label{letter-spacing:.8px;text-transform:uppercase;font-size:10px;color:#777;font-weight:800}
        .actions{display:flex;gap:6px;justify-content:flex-end;margin-top:11px}
        .message{font-size:11px;color:#555;margin:8px 0 0;overflow-wrap:anywhere;min-height:15px}
      </style>
      <div class="card">
        <div class="top"><span>▶ AUTO VIDEO <span style="color:#888;font-size:10px">V3.1</span></span><button id="av-min" title="Thu gọn hoặc mở rộng" aria-label="Thu gọn hoặc mở rộng">−</button></div>
        <div id="av-details">
          <div id="av-name" class="title">Đang chuẩn bị...</div>
          <div class="row"><span class="label">Video hiện tại</span><span id="av-playtime" class="muted">00:00 / 00:00</span></div>
          <div class="rail thin"><div class="bar" id="av-video-bar"></div></div>
          <div class="row"><span class="label">Danh sách</span><span id="av-counter" class="muted">0 / 0 video</span></div>
          <div class="rail"><div class="bar" id="av-bar"></div></div>
          <div class="row muted"><span id="av-pill" class="tag">Đang chạy</span><span id="av-real-speed">—</span></div>
          <div id="av-status" class="message">Đang chờ video...</div>
          <div class="actions"><button id="av-pause" class="light">Ⅱ Tạm dừng</button><button id="av-stop">■ Dừng</button></div>
        </div>
      </div>`;
    document.documentElement.appendChild(host);
    overlay.getElementById('av-stop').addEventListener('click', async () => {
        try { const x = await send('STOP_RUN'); updateOverlay(x.state); }
        catch (e) { setMessage(e.message); }
    });
    overlay.getElementById('av-pause').addEventListener('click', async () => {
        try { const x = await send(state?.status === 'paused' ? 'RESUME_RUN' : 'PAUSE_RUN'); updateOverlay(x.state); }
        catch (e) { setMessage(e.message); }
    });
    overlay.getElementById('av-min').addEventListener('click', () => {
        const d = overlay.getElementById('av-details');
        d.hidden = !d.hidden;
        overlay.getElementById('av-min').textContent = d.hidden ? '+' : '−';
    });
}
function updateOverlay(s) {
    state = s;
    if (!topFrame || !s || s.status === 'idle') return;
    createOverlay();
    const item = s.queue[s.index] || s.queue[s.queue.length - 1];
    const finished = s.status === 'finished', paused = s.status === 'paused';
    overlay.getElementById('av-name').textContent = finished ? 'Đã phát hết danh sách video' : (item?.title || 'Video');
    overlay.getElementById('av-counter').textContent = `${Math.min(s.index, s.queue.length)} / ${s.queue.length} đã phát hết`;
    overlay.getElementById('av-bar').style.width = `${s.queue.length ? Math.round(Math.min(s.index, s.queue.length) / s.queue.length * 100) : 0}%`;
    overlay.getElementById('av-status').textContent = s.message || '';
    overlay.getElementById('av-pill').textContent = finished ? 'Đã phát hết' : paused ? 'Tạm dừng' : s.status === 'running' ? `Đang phát • ${s.speed}×` : 'Đã dừng';
    overlay.getElementById('av-pause').disabled = !['running','paused'].includes(s.status);
    overlay.getElementById('av-pause').textContent = paused ? '▶ Tiếp tục' : 'Ⅱ Tạm dừng';
    overlay.getElementById('av-stop').disabled = !['running','paused'].includes(s.status);
    renderPlayback(s.playback);
    if (s.playback?.rateLimited && !finished && s.status === 'running') {
        overlay.getElementById('av-status').textContent = `Đã thử ${s.playback.rateAttempts} lần: trình phát vẫn ${s.playback.rate}×, không giữ được ${s.speed}×.`;
    }
}

function getPlayback(video) {
    const t = Number(video.currentTime), duration = Number(video.duration), rate = Number(video.playbackRate);
    return {
        currentTime: Number.isFinite(t) ? t : 0,
        duration: Number.isFinite(duration) ? duration : 0,
        rate: Number.isFinite(rate) ? rate : 1,
        paused: video.paused, waiting: video.readyState < 3,
        rateAttempts: rateFixAttempts,
        rateLimited: rateFixAttempts >= RATE_RETRY_LIMIT && Math.abs(rate - (state?.speed || 1)) >= .05
    };
}
function reportPlayback(video, mode = '', force = false) {
    if (!state || !['running','paused'].includes(state.status)) return;
    if (video !== watchVideo) return;
    const now = Date.now();
    if (!force && now - lastPlaybackReport < 3000) return;
    lastPlaybackReport = now;
    const pb = getPlayback(video);
    if (topFrame) renderPlayback(pb);
    const expected = state.queue[state.index];
    if (!expected) return;
    const currentUrl = topFrame ? location.href : expected.url;
    send('PLAYER_STATUS', { currentUrl, playback: pb, mode }).catch(() => {});
}
function applySpeed(video, reset = false) {
    if (!state || !video || !['running','paused'].includes(state.status)) return;
    if (reset) {
        rateFixAttempts = 0;
        lastRateFix = 0;
        rateWarningShown = false;
    }
    const target = Number(state.speed) || 1;
    const actual = Number(video.playbackRate);
    if (Math.abs(actual - target) < .05) return;
    if (rateFixAttempts >= RATE_RETRY_LIMIT) {
        if (!rateWarningShown) {
            rateWarningShown = true;
            reportPlayback(video, '', true);
        }
        return;
    }
    if (!reset && Date.now() - lastRateFix < RATE_RETRY_INTERVAL_MS) return;
    lastRateFix = Date.now();
    rateFixAttempts++;
    // defaultPlaybackRate may help players that reset to the default when they resume.
    // Do not replace Coursera's media handlers or write fake progress events.
    try { video.defaultPlaybackRate = target; } catch (_) { /* unsupported */ }
    try { video.playbackRate = target; } catch (_) { /* unsupported */ }
    reportPlayback(video, '', true);
}

// Read-only course material discovery. No progress/"ended" API writes or header modification.
async function courseVideoList(slug) {
    const params = new URLSearchParams({
        q: 'slug', slug,
        includes: 'modules,lessons,passableItemGroups,passableItemGroupChoices,passableLessonElements,items',
        fields: 'moduleIds,onDemandCourseMaterialModules.v1(name,lessonIds),onDemandCourseMaterialLessons.v1(name,elementIds),onDemandCourseMaterialPassableItemGroups.v1(passableItemGroupChoiceIds),onDemandCourseMaterialPassableItemGroupChoices.v1(itemIds),onDemandCourseMaterialPassableLessonElements.v1(isRequiredForPassing),onDemandCourseMaterialItems.v2(name,slug,contentSummary,isLocked)',
        showLockedItems: 'true'
    });
    try {
        const response = await fetch('/api/onDemandCourseMaterials.v2/?' + params, {
            method: 'GET', credentials: 'same-origin', signal: AbortSignal.timeout(10000)
        });
        if (!response.ok) return [];
        const result = await response.json();
        const items = result?.linked?.['onDemandCourseMaterialItems.v2'];
        if (!Array.isArray(items)) return [];
        return items.filter(i => i?.contentSummary?.typeName === 'lecture' && i.id && !i.isLocked).map(i => ({
            id: String(i.id),
            url: `${location.origin}/learn/${slug}/lecture/${encodeURIComponent(i.id)}/${encodeURIComponent(i.slug || '')}`.replace(/\/$/, ''),
            title: String(i.name || 'Video')
        }));
    } catch (_) { return []; }
}
function visibleVideoLinks(slug) {
    const found = [], visited = new Set();
    for (const a of document.querySelectorAll('a[href]')) {
        const video = lectureInfo(a.href);
        if (!video || video.slug !== slug || visited.has(video.id)) continue;
        visited.add(video.id);
        found.push({ id: video.id, url: video.url, title: a.textContent.trim() || a.getAttribute('aria-label') || `Video ${found.length + 1}` });
    }
    return found;
}
async function discoverPlaylist(slug) {
    const pageLinks = visibleVideoLinks(slug);
    const apiList = await courseVideoList(slug);
    const fromDom = new Map(pageLinks.map(x => [x.id, x]));
    // API returns the whole course, including collapsed modules; DOM supplies exact lecture URLs.
    let queue = apiList.length ? apiList.map(x => ({ ...x, ...(fromDom.get(x.id) || {}) })) : pageLinks;
    const active = lectureInfo(location.href);
    if (active?.slug === slug && !queue.some(x => x.id === active.id)) {
        queue = [{ id: active.id, url: active.url, title: document.title.split('|')[0].trim() || 'Video hiện tại' }, ...queue];
    }
    // If the outline is fully available in DOM, its visual order is often more reliable.
    if (pageLinks.length >= 2 && pageLinks.length >= apiList.length) {
        queue = [...pageLinks, ...queue.filter(x => !fromDom.has(x.id))];
    }
    const seen = new Set();
    return queue.filter(x => { if (seen.has(x.id)) return false; seen.add(x.id); return true; });
}

function selectVideo() {
    const els = Array.from(document.querySelectorAll('video'));
    if (!els.length) return null;
    return els.filter(v => v.isConnected).sort((a,b) => {
        const area = v => { const r = v.getBoundingClientRect(); return r.width * r.height; };
        return area(b) - area(a);
    })[0] || null;
}
function detachWatcher() {
    if (watchVideo) {
        const handlers = observerCallbacks.get(watchVideo);
        if (handlers) {
            watchVideo.removeEventListener('ended', handlers.ended);
            watchVideo.removeEventListener('loadedmetadata', handlers.metadata);
            for (const [type, fn] of Object.entries(handlers.extra || {})) watchVideo.removeEventListener(type, fn);
        }
        watchVideo = null;
    }
}
async function onEnded(video) {
    if (!state || state.status !== 'running' || endedInFlight || video !== watchVideo) return;
    if (!video.ended) return;
    const active = lectureInfo(topFrame ? location.href : (state.queue[state.index] || {}).url);
    if (!active || !state.queue[state.index] || active.id !== state.queue[state.index].id) return;
    endedInFlight = true;
    setMessage('Video đã phát hết. Đang chuyển bài...');
    try {
        const response = await send('VIDEO_ENDED', { currentUrl: active.url });
        updateOverlay(response.state);
        if (response.nextUrl && topFrame) {
            await new Promise(r => setTimeout(r, DELAY_AFTER_END_MS));
            if (state?.status === 'running') location.assign(response.nextUrl);
        } else if (response.nextUrl && !topFrame) {
            // The top frame receives the state update and navigates on the next sync.
            // Ask the background worker to navigate the tab if the player is nested.
            await send('FRAME_NEXT_NAVIGATION', { nextUrl: response.nextUrl });
        }
    } catch (error) { setMessage('Lỗi chuyển bài: ' + error.message); }
    finally { endedInFlight = false; }
}
async function tryAutoplay(video) {
    if (!state || state.status !== 'running') return;
    const expected = state.queue[state.index];
    if (topFrame && (!expected || lectureInfo(location.href)?.id !== expected.id)) return;
    if (autoplayAttempted.has(video)) return;
    autoplayAttempted.add(video);
    applySpeed(video, true);
    if (video.ended) { await onEnded(video); return; }
    try {
        await video.play();
        setMessage('Đang phát video. Tự chuyển khi phát hết.');
        reportPlayback(video, 'playing', true);
    } catch (_) {
        setMessage('Trình duyệt chặn tự phát: nhấn Play một lần trên video.');
        reportPlayback(video, 'blocked', true);
    }
}
function watchPlayer() {
    if (!state || state.status !== 'running') return;
    if (topFrame) {
        const active = lectureInfo(location.href);
        if (!active || state.queue[state.index]?.id !== active.id) return;
    }
    const nextVideo = selectVideo();
    if (!nextVideo) return;
    if (nextVideo === watchVideo) return;
    detachWatcher();
    watchVideo = nextVideo;
    const ended = () => onEnded(nextVideo);
    const metadata = () => { applySpeed(nextVideo, true); reportPlayback(nextVideo, '', true); };
    const extra = {
        timeupdate: () => { applySpeed(nextVideo); reportPlayback(nextVideo); },
        playing: () => { applySpeed(nextVideo); reportPlayback(nextVideo, 'playing', true); },
        waiting: () => reportPlayback(nextVideo, 'buffering', true),
        pause: () => reportPlayback(nextVideo, state?.status === 'paused' ? '' : 'paused', true),
        ratechange: () => { applySpeed(nextVideo); reportPlayback(nextVideo, '', true); }
    };
    observerCallbacks.set(nextVideo, { ended, metadata, extra });
    nextVideo.addEventListener('ended', ended);
    nextVideo.addEventListener('loadedmetadata', metadata);
    for (const [type, fn] of Object.entries(extra)) nextVideo.addEventListener(type, fn);
    // tryAutoplay applies the speed once; avoid resetting the retry budget twice.
    tryAutoplay(nextVideo);
}
async function resumeFromSession() {
    try {
        const result = await send('GET_STATE');
        state = result.state;
        updateOverlay(state);
        if (state.status !== 'running') { if (state.status === 'paused' && watchVideo) watchVideo.pause(); return; }
        if (topFrame) {
            const active = lectureInfo(location.href);
            if (!active || state.queue[state.index]?.id !== active.id) {
                setMessage('Mở lại video đang chờ để tiếp tục.');
                return;
            }
            const reply = await send('PAGE_READY', { currentUrl: location.href });
            updateOverlay(reply.state);
        }
        watchPlayer();
    } catch (error) {
        if (topFrame) console.debug('[AutoVideo] Không khôi phục được phiên:', error.message);
    }
}
async function start(speed) {
    if (!topFrame) throw new Error('Chỉ điều khiển trên trang khóa học chính.');
    const slug = courseSlug();
    if (!slug) throw new Error('Mở trang /learn/<khóa-học>/... trước khi chạy.');
    autoplayAttempted = new WeakSet();
    createOverlay();
    setMessage('Đang tìm video...');
    const queue = await discoverPlaylist(slug);
    if (!queue.length) throw new Error('Không tìm thấy video. Hãy mở một bài video trong khóa học trước.');
    const response = await send('START_RUN', { queue, courseSlug: slug, currentUrl: location.href, speed });
    updateOverlay(response.state);
    const current = lectureInfo(location.href);
    if (!current || current.id !== response.state.queue[response.state.index].id) {
        location.assign(response.nextUrl);
    } else {
        await send('PAGE_READY', { currentUrl: location.href });
        watchPlayer();
    }
    return { ok: true, count: queue.length, state: response.state };
}

chrome.runtime.onMessage.addListener((request, sender, respond) => {
    if (request.action === 'CONTENT_PING') { respond({ ok: true }); return; }
    if (request.action === 'SYNC_STATE') {
        const wasStatus = state?.status, wasSpeed = state?.speed;
        updateOverlay(request.state);
        if (state?.status === 'running') {
            if (wasStatus !== 'running') autoplayAttempted = new WeakSet();
            if (watchVideo) {
                applySpeed(watchVideo, wasSpeed !== state.speed);
                if (wasStatus === 'paused') {
                    autoplayAttempted = new WeakSet();
                    tryAutoplay(watchVideo);
                }
            }
            watchPlayer();
        } else {
            if (['paused','stopped'].includes(state?.status) && watchVideo && !watchVideo.paused) watchVideo.pause();
            detachWatcher();
            if (state?.status === 'paused') autoplayAttempted = new WeakSet();
        }
        respond({ ok: true });
        return;
    }
    if (request.action === 'AUTO_VIDEO_START' && topFrame) {
        start(Number(request.speed) || 1).then(respond).catch(e => respond({ ok: false, error: e.message }));
        return true;
    }
});

// Coursera uses client-side navigation. Detect route/player replacement without POSTing progress.
function scan() {
    if (location.href !== urlSeen) {
        urlSeen = location.href;
        detachWatcher();
        autoplayAttempted = new WeakSet();
        endedInFlight = false;
        resumeFromSession();
        if (topFrame) send('MONITOR_HELLO',{currentUrl:location.href}).catch(()=>{});
    }
    if (state?.status === 'running') {
        watchPlayer();
        // Coursera có thể đặt lại tốc độ mà không thay phần tử <video>.
        if (watchVideo && !watchVideo.ended) applySpeed(watchVideo);
    }
    if (topFrame && state && state.status !== 'idle' && Date.now() - lastStatePull > 2400) {
        lastStatePull = Date.now();
        send('GET_STATE').then(result => updateOverlay(result.state)).catch(() => {});
    }
}
scanTimer = setInterval(scan, 1300);
const mutationObserver = new MutationObserver(() => {
    if (!state || state.status !== 'running') return;
    clearTimeout(scan._timer);
    scan._timer = setTimeout(scan, 300);
});
mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
resumeFromSession();
if (topFrame) setTimeout(()=>send('MONITOR_HELLO',{currentUrl:location.href}).catch(()=>{}),1500);
})();
