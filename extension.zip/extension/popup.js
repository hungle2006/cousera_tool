'use strict';
const $ = id => document.getElementById(id);
let activeTabId = null;
let currentState = null;
let busy = false;
const speeds = [1, 1.25, 1.5, 1.75, 2, 3, 4];
const fmt = seconds => {
    if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
    const value = Math.floor(seconds);
    const n = value % 60, m = Math.floor(value / 60) % 60, h = Math.floor(value / 3600);
    return h ? `${h}:${String(m).padStart(2,'0')}:${String(n).padStart(2,'0')}` : `${String(m).padStart(2,'0')}:${String(n).padStart(2,'0')}`;
};
function err(message) { $('error').textContent = message; $('error').classList.toggle('visible', !!message); }
function isCourseraTab(tab) { return !!tab?.url && /^https:\/\/([\w-]+\.)*coursera\.org\//i.test(tab.url); }
async function backend(action, args = {}) {
    const result = await chrome.runtime.sendMessage({ action, tabId: activeTabId, ...args });
    if (!result?.ok) throw new Error(result?.error || 'Tiện ích không phản hồi.');
    return result;
}
function draw(s) {
    currentState = s;
    const status = s?.status || 'idle';
    const running = status === 'running', paused = status === 'paused', done = status === 'finished';
    const total = s?.queue?.length || 0;
    const count = Math.min(s?.index || 0, total);
    const pb = s?.playback || {};
    const activePlayback = (running || paused) && !!pb.duration;
    const current = activePlayback ? Math.max(0, Math.min(pb.currentTime || 0, pb.duration)) : 0;
    const duration = activePlayback ? pb.duration : 0;
    const videoPct = duration ? Math.round(current / duration * 100) : 0;
    const pct = total ? Math.round(count / total * 100) : 0;
    $('videoName').textContent = done ? 'Đã phát hết danh sách video' : s?.queue?.[s.index]?.title || 'Chưa bắt đầu';
    $('videoIndex').textContent = total ? `${Math.min(count+1,total)} / ${total}` : '— / —';
    $('currentTime').textContent = `${fmt(current)} / ${fmt(duration)}`;
    $('currentPercent').textContent = `${videoPct}%`;
    $('currentFill').style.width = `${videoPct}%`;
    $('videoCount').textContent = `${count} / ${total} video đã phát hết`;
    $('percent').textContent = `${pct}%`; $('fill').style.width = `${pct}%`;
    $('remaining').textContent = `Còn ${Math.max(0,total-count)} video`;
    $('completed').textContent = count; $('pending').textContent = Math.max(0,total-count);
    $('effectiveSpeed').textContent = activePlayback && pb.rate ? `${pb.rate}×` : '—';
    $('badgeText').textContent = running ? 'Đang tự động' : paused ? 'Đã tạm dừng' : done ? 'Đã phát hết' : status === 'stopped' ? 'Đã dừng' : 'Sẵn sàng';
    $('led').className = `led ${running ? 'active' : done ? 'finished' : ''}`;
    $('headerSpeed').textContent = `${s?.speed || 1}× SPEED`;
    $('updatedTime').textContent = s?.updatedAt ? new Date(s.updatedAt).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',second:'2-digit'}) : '—';
    $('statusText').textContent = s?.message || 'Mở trang Coursera để bắt đầu.';
    const mismatch = activePlayback && pb.rate && Math.abs(pb.rate - (s.speed || 1)) > .05;
    $('hint').textContent = (mismatch && pb.rateLimited)
        ? `Đã thử áp dụng ${s.speed}× ${pb.rateAttempts} lần nhưng trình phát vẫn ở ${pb.rate}×. Có thể Coursera giới hạn tốc độ. Bạn có thể thử đổi tốc độ hoặc phát lại; tool không thể cam kết 4×.`
        : mismatch
            ? `Đang thử đồng bộ ${s.speed}× • tốc độ hiện tại ${pb.rate}× • lần thử ${pb.rateAttempts || 0}/12. Nếu trình phát tiếp tục đưa về ${pb.rate}×, tool sẽ dừng thử và báo rõ.`
            : 'Video phát đến cuối → tự chuyển video tiếp theo. Không tự làm Quiz hoặc Reading.';
    $('start').disabled = busy || running || paused || !activeTabId;
    $('pause').disabled = busy || !activeTabId || (!running && !paused);
    $('pause').textContent = paused ? '▶ Tiếp tục' : 'Ⅱ Tạm dừng';
    $('stop').disabled = busy || !activeTabId || (!running && !paused);
    $('speed').disabled = busy || !activeTabId;
    if (s?.speed && speeds.includes(s.speed) && s.status !== 'idle') $('speed').value = String(s.speed);
    const log = Array.isArray(s?.events) ? s.events.slice(-4).reverse() : [];
    $('activity').replaceChildren();
    if (!log.length) { const d = document.createElement('div'); d.textContent = 'Chưa có hoạt động.'; $('activity').append(d); }
    for (const item of log) {
        const line = document.createElement('div'), time = document.createElement('time'), msg = document.createElement('em');
        time.textContent = new Date(item.at).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
        msg.textContent = item.message; line.append(time,msg); $('activity').append(line);
    }
}
async function refresh() {
    if (!activeTabId || busy) return;
    try { draw((await backend('GET_STATE')).state); }
    catch (error) { err(error.message); }
}
async function contentStart(tabId, speed) {
    try { await chrome.tabs.sendMessage(tabId, { action: 'CONTENT_PING' }, { frameId: 0 }); }
    catch (_) { await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ['content.js'] }); }
    return chrome.tabs.sendMessage(tabId, { action: 'AUTO_VIDEO_START', speed }, { frameId: 0 });
}
$('start').addEventListener('click', async () => {
    if (busy || !activeTabId) return;
    const speed = Number($('speed').value); busy = true; err('');
    $('start').textContent = 'Đang tìm video…';
    try { const r = await contentStart(activeTabId, speed); if (!r?.ok) throw new Error(r?.error || 'Không thể bắt đầu.'); draw(r.state); }
    catch (e) { err(e.message); }
    finally { busy = false; $('start').textContent = '▶ Bắt đầu'; await refresh(); }
});
$('pause').addEventListener('click', async () => {
    if (busy || !activeTabId) return;
    busy = true; err('');
    try { draw((await backend(currentState?.status === 'paused' ? 'RESUME_RUN' : 'PAUSE_RUN')).state); }
    catch (e) { err(e.message); }
    finally { busy = false; await refresh(); }
});
$('stop').addEventListener('click', async () => {
    if (busy || !activeTabId) return;
    busy = true; err('');
    try { draw((await backend('STOP_RUN')).state); }
    catch (e) { err(e.message); }
    finally { busy = false; await refresh(); }
});
$('speed').addEventListener('change', async () => {
    if (busy || !activeTabId) return;
    const speed = Number($('speed').value);
    chrome.storage.local.set({ autoVideoPreferredSpeed: speed }).catch(() => {});
    if (!currentState || currentState.status === 'idle') return;
    try { draw((await backend('SET_SPEED', { speed })).state); }
    catch (e) { err(e.message); }
});
(async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!isCourseraTab(tab)) {
        $('statusText').textContent = 'Hãy mở một bài video tại coursera.org/learn/...';
        $('videoName').textContent = 'Chưa ở trang Coursera';
        $('start').disabled = true;
        $('speed').disabled = true;
        return;
    }
    activeTabId = tab.id;
    try {
        const pref = await chrome.storage.local.get('autoVideoPreferredSpeed');
        if (speeds.includes(pref.autoVideoPreferredSpeed)) $('speed').value = String(pref.autoVideoPreferredSpeed);
    } catch (_) { /* optional saved preference */ }
    await refresh();
    setInterval(refresh, 1200);
})().catch(e => err(e.message));
