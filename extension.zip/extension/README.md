# Coursera Control Center v5.5 — sửa lỗi `Receiving end does not exist` (24/10/2026)

**Nguyên nhân thực tế:** Cloudflare D1 nhận heartbeat và lệnh từ Vercel nhưng extension v5.4 sử dụng `chrome.runtime.sendMessage(...)` bên trong chính MV3 background service worker để gọi handler của cùng worker. Chrome không gửi message ngược về sender, dẫn đến lỗi `Could not establish connection. Receiving end does not exist.` cho cả `pause`, `resume`, `stop`.

**Đã sửa (chỉ Chrome Extension):**

1. `extension/background.js`: rút xử lý `PAUSE_RUN` / `RESUME_RUN` / `STOP_RUN` vào hàm dùng chung trong cùng service worker; gọi trực tiếp qua `globalThis.applyVideoCommandFromMonitor`, vẫn giữ bộ xử lý từ popup và content script.
2. `extension/monitor-background.js`: gọi hàm trên **trực tiếp**, không gửi `runtime.sendMessage` đến background; kiểm tra video HTML5 thực sự thay đổi và gửi `applied` / `failed` qua `/client/ack`.
3. Thống nhất các lần kiểm tra lệnh đồng thời, tránh một lần kết nối trả về trong khi quá trình polling vẫn đang xử lý.
4. `extension/test_remote_controls.js`: kiểm thử tích hợp thực tế cả hai tệp JS trong *cùng một service worker giả lập*. Giả lập Chrome báo `Receiving end does not exist` nếu `runtime.sendMessage` bị gọi từ worker; vẫn kiểm tra pause, resume, stop, chọn đúng tab, ACK, và rollback nếu Chrome từ chối Play.

**Kết quả:** 20/20 test của Cloudflare Worker; các bài kiểm thử extension background, monitor, remote controls, speed và syntax đều đạt. **Chưa kiểm thử Chrome Coursera thật** — yêu cầu cài bản v5.5 vào máy để xác nhận.

**Nâng cấp giữ nguyên token/setting:**

- Để **giữ nguyên token đã kết nối**, có thể sao lưu thư mục extension v5.4 rồi **chép đè các tệp trong thư mục `extension/` v5.5 vào đúng thư mục đang được Chrome Load unpacked**, trở lại `chrome://extensions` bấm **Reload**. Nhờ giữ cùng đường dẫn/ID của unpacked extension, dữ liệu `chrome.storage` thông thường vẫn giữ.
- Nếu chọn gỡ bản cũ và `Load unpacked` thư mục `extension/` mới thì bạn có thể cần nhập lại **token tài khoản** (không phải ADMIN TOKEN), được cấp ở Vercel → Tài khoản → Đổi token.
- **Mở lại / F5 trang Coursera đang phát video** sau khi reload extension, để content script mới được nạp vào trang.
- Vào đúng video `/learn/<slug>/lecture/...`, bấm **Bắt đầu** trong tiện ích nếu chưa có phiên video. Kiểm tra dashboard: gửi **Tạm dừng**, chờ tối đa chu kỳ kiểm tra khoảng 30 giây, xem tab Nhật ký. Thử lại Tiếp tục và Dừng.
- **Không chạy lại Modal, không deploy lại Cloudflare/Vercel và không tạo lại tài khoản.** Sửa lỗi chỉ nằm trong extension.

Nếu sau v5.5 vẫn báo thất bại, gửi nguyên dòng lỗi mới từ mục Nhật ký. Lỗi liên quan Coursera player, autoplay hoặc iframe có thể cần xử lý riêng; không coi lệnh thành công khi video thực tế không chạy.

---

# Coursera Control Center Connector v5.4

## Sửa lỗi dashboard có lệnh nhưng Chrome không phản hồi

Bản v5.4 sửa cơ chế điều khiển từ xa và chỉ có hiệu lực sau khi cập nhật extension trong Chrome.

- Giữ kết nối Cloudflare D1 bằng token riêng của tài khoản; không cần tạo tài khoản lại.
- Tìm đúng tab đang có phiên video (`running`/`paused`) nếu Chrome mở nhiều tab Coursera.
- Quét lệnh server ít nhất theo chu kỳ báo thức 30 giây khi Chrome có thể chạy extension; các sự kiện trạng thái video cũng kích hoạt kiểm tra sớm hơn.
- Nhận `pause`, `resume`, `stop`; áp dụng cho phiên video của extension và thử điều khiển phần tử HTML5 `<video>` trên trang (nếu truy cập được).
- Chỉ gửi xác nhận thành công cho lệnh `resume` khi có video thật sự chuyển sang trạng thái phát; nếu Chrome chặn autoplay hoặc không tìm thấy video, gửi kết quả thất bại có lý do và đưa phiên về paused.
- Không tự đăng nhập Coursera, không ghi tiến độ/chứng chỉ giả, không tự nộp bài kiểm tra.

## Cài bản mới (phải làm trên Chrome đang dùng)

1. Giải nén ZIP v5.4 vào thư mục ổn định.
2. Vào `chrome://extensions`. Gỡ tiện ích cũ **hoặc** chỉ đè các file của bản mới vào thư mục tiện ích cũ rồi bấm **Reload**. Nếu gỡ/cài lại, có thể cần nhập lại token tài khoản.
3. Chọn **Load unpacked** → thư mục `extension/` trong ZIP v5.4.
4. Mở **đúng bài video** `https://www.coursera.org/learn/.../lecture/...` (không chỉ trang chủ khóa học).
5. Trên extension, nhập Worker URL và token tài khoản đúng, bật giám sát server rồi bấm **Lưu & kết nối**.
6. Nhấn **Bắt đầu** trong tab điều khiển video của extension ít nhất một lần để có danh sách video (khởi tạo phiên). Nếu Chrome chặn autoplay, nhấn Play thủ công trên trang.
7. Mở `https://coursera-control-center.vercel.app`, chọn đúng tài khoản rồi bấm Tạm dừng / Tiếp tục / Dừng. Ở dashboard sẽ hiển thị **Đang chờ xác nhận**, **Đã xác nhận** hoặc **Thất bại**.

## Các trường hợp thường gặp

| Tình huống | Nguyên nhân / cách xử lý |
|---|---|
| `Chưa bấm Bắt đầu trong extension` | Vào bài video rồi nhấn Bắt đầu trên extension một lần |
| `Không tìm thấy video đang mở` | Chuyển sang đường dẫn `/learn/<slug>/lecture/...` và chờ video tải |
| `Trình phát từ chối phát tiếp` | Chrome/Coursera chặn autoplay hoặc iframe không điều khiển được; nhấn Play trên video |
| Lệnh `pending` kéo dài | Chrome đã đóng, extension tắt, mất mạng, tab không còn ở khóa Coursera hoặc service worker không được kích hoạt |
| `running` nhưng video đang Pause | `running` là trạng thái chế độ tự động trong extension; thông báo video thực tế nằm ở mục Thông báo/phát video |
| Đã đổi token tài khoản | Phải nhập token **mới** vào extension rồi lưu kết nối |

`ADMIN_TOKEN` chỉ dành cho dashboard; **không** nhập vào extension. Không có tính năng cloud browser chạy độc lập khi Chrome đóng; Modal hiện là phép thử kết nối.
