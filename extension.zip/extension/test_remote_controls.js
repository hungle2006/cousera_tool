'use strict';
// Integration regression for MV3: background.js imports monitor-background.js in
// one service-worker realm. chrome.runtime.sendMessage() MUST NOT be called by
// the remote poller to dispatch a background-only control command.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const initial={
  11:{status:'idle',queue:[],index:0,courseSlug:'sample-course',message:'Homepage'},
  22:{status:'running',queue:[{id:'a',title:'A',url:'https://www.coursera.org/learn/sample-course/lecture/a'}],index:0,courseSlug:'sample-course',message:'Playing'}
};
const sessions=new Map(Object.entries(initial).map(([id,v])=>['videoRun_'+id,structuredClone(v)]));
const local={aiAssistantConfig:{worker:'https://example.workers.dev',token:'long_scoped_test_token'},autoVideoMonitorConfig:{enabled:true,autoStart:false}};
const commands=[],acks=[],runtimeListeners=[],mediaActions=[];
let selfMessages=0,contentBroadcasts=0,playerPaused=false,playerCanPlay=true,alarmPeriod=0;
const chrome={
  storage:{
    local:{get:async keys=>Object.fromEntries(keys.map(k=>[k,local[k]])),set:async x=>Object.assign(local,x)},
    session:{
      get:async key=>({[key]:structuredClone(sessions.get(key))}),
      set:async x=>{for(const [k,v] of Object.entries(x))sessions.set(k,structuredClone(v))},
      remove:async key=>sessions.delete(key)
    }
  },
  action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},
  notifications:{create:async()=>{}},
  tabs:{
    get:async id=>({id,url:id===11?'https://www.coursera.org/learn/sample-course/home':'https://www.coursera.org/learn/sample-course/lecture/a',active:id===11}),
    query:async()=>[
      {id:11,url:'https://www.coursera.org/learn/sample-course/home',active:true},
      {id:22,url:'https://www.coursera.org/learn/sample-course/lecture/a',active:false}
    ],
    sendMessage:async()=>{contentBroadcasts++;throw Error('Receiving end does not exist (content script not ready)')},
    update:async()=>{},onRemoved:{addListener:()=>{}}
  },
  runtime:{
    onMessage:{addListener:f=>runtimeListeners.push(f)},
    onStartup:{addListener:()=>{}},
    sendMessage:async()=>{selfMessages++;throw Error('Could not establish connection. Receiving end does not exist.')}
  },
  scripting:{executeScript:async({target,args})=>{
    const command=args[0];mediaActions.push({tabId:target.tabId,command});
    if(command==='resume'&&playerCanPlay)playerPaused=false;
    if(command==='pause'||command==='stop')playerPaused=true;
    return [{result:{found:true,paused:playerPaused,playing:!playerPaused,errors:playerCanPlay?[]:['NotAllowedError']}}];
  }},
  alarms:{create:async(name,opts)=>{alarmPeriod=opts.periodInMinutes},onAlarm:{addListener:()=>{}}}
};
const fetch=async(url,opts={})=>{
  const path=new URL(url).pathname;
  if(path==='/client/heartbeat')return {ok:true,json:async()=>({ok:true,account_id:'test_1',desired_state:'running'})};
  if(path==='/client/commands')return {ok:true,json:async()=>({ok:true,commands:commands.splice(0)})};
  if(path==='/client/ack'){acks.push(JSON.parse(opts.body));return {ok:true,json:async()=>({ok:true})}}
  throw Error('Unexpected fetch '+url);
};
const context=vm.createContext({chrome,fetch,console,URL,AbortController,Date,Map,Set,Number,Error,String,Boolean,Array,JSON,setTimeout,clearTimeout});
context.importScripts=(name)=>vm.runInContext(fs.readFileSync(__dirname+'/'+name,'utf8'),context,{filename:name});
vm.runInContext(fs.readFileSync(__dirname+'/background.js','utf8'),context,{filename:'background.js'});
async function sendFromPopup(request){return new Promise((resolve,reject)=>{
  let done=false;
  const timer=setTimeout(()=>{if(!done)reject(Error('Message timed out'))},2400);
  for(const fn of runtimeListeners){const result=fn(request,{},answer=>{if(done)return;done=true;clearTimeout(timer);resolve(answer)});if(result===true)return}
  clearTimeout(timer);reject(Error('No extension receiver'));
})}
(async()=>{
  assert.equal(alarmPeriod,0.5);
  const target=()=>sessions.get('videoRun_22');
  for(const [id,action,state,wantPaused] of [['p','pause','paused',true],['r','resume','running',false],['s','stop','stopped',true]]){
    commands.push({id,action});
    const response=await sendFromPopup({action:'MONITOR_CONNECT',tabId:11});
    assert.equal(response.ok,true,'monitor connects');
    assert.equal(acks.at(-1).command_id,id);
    assert.equal(acks.at(-1).result,'applied');
    assert.equal(target().status,state);
    assert.equal(playerPaused,wantPaused);
    assert.equal(mediaActions.at(-1).tabId,22,'must control video tab, not course homepage');
  }
  commands.push({id:'r2',action:'resume'});playerCanPlay=false;
  const r=await sendFromPopup({action:'MONITOR_CONNECT',tabId:11});
  assert.equal(r.ok,true);
  assert.equal(acks.at(-1).result,'failed','must not claim applied when video rejects playback');
  assert.match(acks.at(-1).error,/từ chối phát tiếp/);
  assert.equal(target().status,'paused','failure rolls back local state');
  assert.equal(selfMessages,0,'NEVER send self-message from MV3 worker');
  assert(contentBroadcasts>0,'still broadcasts state to content script when available');
  console.log('PASS: one MV3 worker / direct dispatch / tab selection / real pause-resume-stop / ack / rollback / no self-messaging');
})().catch(e=>{console.error(e);process.exitCode=1});
