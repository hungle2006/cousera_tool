(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  let worker='';
  $('monitorStatus').textContent='Nhập Worker URL + token ở trên, rồi bật giám sát để kết nối.';
  async function init(){const data=await chrome.storage.local.get('autoVideoMonitorConfig');$('monitorEnabled').checked=data.autoVideoMonitorConfig?.enabled===true;$('monitorAutoStart').checked=data.autoVideoMonitorConfig?.autoStart===true;}
  $('monitorConnect').addEventListener('click',async()=>{
    $('monitorConnect').disabled=true;const status=msg=>$('monitorStatus').textContent=msg;
    try{
      const u=new URL($('workerUrl').value.trim());if(u.protocol!=='https:'||u.search||u.hash||u.username||u.password||u.port)throw Error('Cần Worker URL HTTPS hợp lệ.');
      worker=u.origin;const token=$('appToken').value.trim();if(!token)throw Error('Cần token tài khoản được cấp từ dashboard Vercel.');
      const enabled=$('monitorEnabled').checked,autoStart=$('monitorAutoStart').checked;
      if(autoStart&&!enabled)throw Error('Phải bật giám sát nếu muốn tự phát video.');
      // Must request optional host access from a user gesture, not in the background.
      const allowed=await chrome.permissions.request({origins:[worker+'/*']});if(!allowed)throw Error('Chrome chưa cho phép truy cập Worker.');
      await chrome.storage.local.set({aiAssistantConfig:{worker,token,mode:$('aiMode').value},autoVideoMonitorConfig:{enabled,autoStart}});
      if(!enabled){status('Đã lưu, giám sát đang tắt.');return;}
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      if(!tab?.id || !/^https:\/\/([\w-]+\.)*coursera\.org\//i.test(tab.url||'')){
        status('Đã lưu. Mở một trang khóa học Coursera để server tự nhận diện.');
      } else {
        const r=await chrome.runtime.sendMessage({action:'MONITOR_CONNECT',tabId:tab.id});
        if(!r?.ok)throw Error(r?.error||'Không kết nối được');
        status('✓ Đã kết nối tài khoản '+r.accountId+'. Dashboard nhận heartbeat và điều khiển từ xa khi Chrome đang mở.');
      }
      $('monitorOpenDashboard').disabled=false;
    }catch(error){status('Lỗi: '+error.message);}finally{$('monitorConnect').disabled=false;}
  });
  $('monitorOpenDashboard').addEventListener('click',()=>{if(worker)chrome.tabs.create({url:'https://coursera-control-center.vercel.app'});});
  init().catch(()=>{});
})();
