const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const data = new Map();
let sendHandlers=[], notifications=0, badges=[];
const chrome = {
  storage: {session: {async get(k){return {[k]:data.get(k)};},async set(obj){for (const [k,v] of Object.entries(obj)) data.set(k,structuredClone(v));},async remove(k){data.delete(k);} }},
  action: {async setBadgeText(x){badges.push(x.text)},async setBadgeBackgroundColor(){}},
  notifications:{async create(){notifications++}},
  tabs:{async sendMessage(){},async update(){},onRemoved:{addListener(){}}},
  runtime:{onMessage:{addListener(fn){sendHandlers.push(fn);}}}
};
// Importing the separate monitor bridge is tested by test_monitor.js.
vm.runInNewContext(fs.readFileSync(__dirname+'/background.js','utf8'),{chrome,Date, URL,Number, Set,Array, console, importScripts:()=>{}});
async function message(action,opts={}){
  return new Promise((resolve,reject)=>{const msg={action,tabId:22,...opts};const accepted=sendHandlers.some(fn=>fn(msg,{},resolve)===true);if(!accepted)reject(Error('no response'))}).then(x=>{if(!x.ok)throw Error(x.error);return x;});
}
(async()=>{
 const queue=[
  {id:'a',url:'https://www.coursera.org/learn/test-course/lecture/a/one',title:'One'},
  {id:'b',url:'https://www.coursera.org/learn/test-course/lecture/b/two',title:'Two'}
 ];
 let a=await message('START_RUN',{courseSlug:'test-course', queue,currentUrl:queue[0].url,speed:4});
 assert.equal(a.state.speed,4); assert.equal(a.state.status,'running'); assert.equal(a.state.queue.length,2);
 a=await message('PLAYER_STATUS',{currentUrl:queue[0].url, playback:{currentTime:30,duration:100,rate:4},mode:'playing'});
 assert.equal(a.state.playback.rate,4); assert.equal(a.state.playback.currentTime,30);
 a=await message('PAUSE_RUN'); assert.equal(a.state.status,'paused');
 a=await message('PLAYER_STATUS',{currentUrl:queue[0].url,playback:{currentTime:31,duration:100,rate:4},mode:'paused'});assert.equal(a.state.message,'Đã tạm dừng video và chế độ tự động');
 a=await message('RESUME_RUN'); assert.equal(a.state.status,'running');
 a=await message('SET_SPEED',{speed:3}); assert.equal(a.state.speed,3);
 a=await message('VIDEO_ENDED',{currentUrl:queue[0].url}); assert.equal(a.nextUrl,queue[1].url);assert.equal(a.state.index,1);
 a=await message('PAGE_READY',{currentUrl:queue[1].url}); assert.equal(a.state.nextPending,undefined);
 a=await message('VIDEO_ENDED',{currentUrl:queue[1].url}); assert.equal(a.state.status,'finished'); assert.equal(a.state.index,2);
 assert.equal(notifications,1);
 assert(a.state.events.some(x=>x.message.includes('Đã phát hết danh sách')));
 console.log('PASS: speeds 4x/3x, playback time, pause/resume, navigation, completion and notification');
})().catch(e=>{console.error(e); process.exit(1)});
