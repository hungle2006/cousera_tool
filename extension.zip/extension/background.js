'use strict';

// Session data is scoped to an individual browser tab and is not sent to any third party.
const prefix = 'videoRun_';
const allowedSpeeds = [1, 1.25, 1.5, 1.75, 2, 3, 4];
function logEvent(state, message) {
    state.events = [...(state.events || []), { at: Date.now(), message: String(message).slice(0, 140) }].slice(-16);
}
const getKey = tabId => prefix + tabId;
const baseState = () => ({ status: 'idle', index: 0, queue: [], speed: 1, courseSlug: '',
    message: 'Sẵn sàng', playback: null, events: [], updatedAt: Date.now() });

async function readState(tabId) {
    if (!Number.isInteger(tabId)) throw new Error('Không tìm thấy tab Coursera.');
    const entry = await chrome.storage.session.get(getKey(tabId));
    return entry[getKey(tabId)] || baseState();
}
async function writeState(tabId, value) {
    value.updatedAt = Date.now();
    await chrome.storage.session.set({ [getKey(tabId)]: value });
    if (typeof globalThis.publishMonitorState === 'function') globalThis.publishMonitorState(tabId,value).catch(()=>{});
    const badge = value.status === 'running' ? `${value.index}/${value.queue.length}` :
        value.status === 'finished' ? '✓' : value.status === 'paused' ? 'Ⅱ' : ''; 
    try {
        await chrome.action.setBadgeText({ tabId, text: badge });
        await chrome.action.setBadgeBackgroundColor({ tabId, color: '#111111' });
    } catch (_) { /* tab may already be closed */ }
}
async function notifyFinished(state) {
    const count = state.queue.length;
    try {
        await chrome.notifications.create(`coursera-auto-video-${Date.now()}`, {
            type: 'basic',
            iconUrl: 'assets/icon128.png',
            title: 'Đã phát hết video!',
            message: `Đã phát xong ${count} video trong danh sách tìm được. Hãy kiểm tra tiến độ trên Coursera.`,
            priority: 1
        });
    } catch (_) { /* notification blocked by browser OS */ }
}
function cleanQueue(raw, slug) {
    if (!Array.isArray(raw) || raw.length > 1000) throw new Error('Danh sách video không hợp lệ.');
    const dedup = new Set();
    const result = [];
    for (const entry of raw) {
        if (!entry || typeof entry.url !== 'string') continue;
        let target;
        try { target = new URL(entry.url); } catch (_) { continue; }
        const segments = target.pathname.split('/').filter(Boolean);
        if (target.protocol !== 'https:' || !/(^|\.)coursera\.org$/.test(target.hostname) ||
            segments[0] !== 'learn' || segments[1] !== slug || segments[2] !== 'lecture' || !segments[3]) continue;
        const id = String(segments[3]);
        if (dedup.has(id)) continue;
        dedup.add(id);
        result.push({ id, url: target.origin + target.pathname, title: String(entry.title || `Video ${result.length + 1}`).slice(0, 180) });
    }
    return result;
}
function sameVideo(url, entry) {
    try {
        const tokens = new URL(url).pathname.split('/').filter(Boolean);
        return tokens[2] === 'lecture' && tokens[3] === entry.id;
    } catch (_) { return false; }
}
async function broadcast(tabId, state) {
    try { await chrome.tabs.sendMessage(tabId, { action: 'SYNC_STATE', state }); }
    catch (_) { /* content not ready during navigation */ }
}

// Share the same tab-state transition code between popup/content messages and the
// remote command poller running inside this MV3 service worker. A service worker
// must not use chrome.runtime.sendMessage() to talk to its own onMessage listener:
// the sender is excluded from delivery and Chrome reports "Receiving end does not exist".
async function handleVideoAction(request, sender = {}) {
        const id = sender.tab?.id ?? request?.tabId;
        if (!Number.isInteger(id) || !request || typeof request.action !== 'string') throw new Error('Yêu cầu không hợp lệ.');
        // Mutating commands must originate in the associated tab or from this extension's popup.
        if (sender.tab?.id !== undefined && sender.tab.id !== id) throw new Error('Sai tab.');
        if (sender.tab && !/^https:\/\/([a-z\d-]+\.)*coursera\.org\//i.test(sender.tab.url || '')) {
            throw new Error('Chỉ hoạt động trên Coursera.');
        }
        let state = await readState(id);
        if (request.action === 'GET_STATE') return { ok: true, state };

        if (request.action === 'START_RUN') {
            const slug = String(request.courseSlug || '');
            if (!/^[\w-]+$/.test(slug)) throw new Error('Không xác định được khóa học.');
            const queue = cleanQueue(request.queue, slug);
            if (!queue.length) throw new Error('Không tìm thấy video nào để phát.');
            // A run begins from the currently open lecture, not from already-passed videos.
            const currentPosition = queue.findIndex(x => sameVideo(request.currentUrl, x));
            const runQueue = currentPosition > 0 ? queue.slice(currentPosition) : queue;
            const index = 0;
            const speed = Number(request.speed);
            state = {
                status: 'running', queue: runQueue, index, courseSlug: slug,
                speed: allowedSpeeds.includes(speed) ? speed : 1,
                message: 'Đang chuẩn bị phát video', playback: null, events: [], updatedAt: Date.now()
            };
            logEvent(state, `Bắt đầu tự động • ${runQueue.length} video • ${state.speed}×`);
            await writeState(id, state);
            await broadcast(id, state);
            return { ok: true, state, nextUrl: runQueue[index].url };
        }
        if (request.action === 'STOP_RUN') {
            state.status = 'stopped';
            state.message = 'Đã dừng theo yêu cầu';
            logEvent(state, 'Đã dừng tự động');
            await writeState(id, state);
            await broadcast(id, state);
            return { ok: true, state };
        }
        if (request.action === 'PAUSE_RUN') {
            if (state.status !== 'running') return {ok: true, state};
            state.status = 'paused';
            state.message = 'Đã tạm dừng video và chế độ tự động';
            logEvent(state, 'Tạm dừng video');
            await writeState(id, state); await broadcast(id, state);
            return {ok: true, state};
        }
        if (request.action === 'RESUME_RUN') {
            if (!['paused','stopped'].includes(state.status)) return {ok: true, state};
            state.status = 'running';
            state.message = 'Đã tiếp tục phát video';
            logEvent(state, 'Tiếp tục phát video');
            await writeState(id, state); await broadcast(id, state);
            return {ok: true, state};
        }
        if (request.action === 'SET_SPEED') {
            if (!allowedSpeeds.includes(Number(request.speed))) throw new Error('Tốc độ không hợp lệ.');
            state.speed = Number(request.speed);
            logEvent(state, `Đổi tốc độ yêu cầu thành ${state.speed}×`);
            await writeState(id, state);
            await broadcast(id, state);
            return { ok: true, state };
        }
        if (request.action === 'PLAYER_STATUS') {
            if (state.status !== 'running' && state.status !== 'paused') return {ok: true, state};
            if (!state.queue[state.index] || !sameVideo(request.currentUrl, state.queue[state.index])) return {ok: true, state};
            const raw = request.playback || {};
            const rateAttempts = Number(raw.rateAttempts);
            const duration = Number(raw.duration), currentTime = Number(raw.currentTime), rate = Number(raw.rate);
            if (Number.isFinite(duration) && duration > 0 && duration < 86400 &&
                Number.isFinite(currentTime) && currentTime >= 0 && currentTime <= duration + 10 &&
                Number.isFinite(rate) && rate > 0 && rate <= 16) {
                state.playback = {
                    currentTime, duration, rate,
                    paused: Boolean(raw.paused), waiting: Boolean(raw.waiting),
                    at: Date.now(),
                    rateAttempts: Number.isInteger(rateAttempts) && rateAttempts >= 0 && rateAttempts <= 100 ? rateAttempts : 0,
                    rateLimited: raw.rateLimited === true
                };
            }
            const mode = String(request.mode || '');
            if (mode === 'blocked' && state.status === 'running') state.message = 'Autoplay bị chặn — hãy nhấn Play trên video';
            else if (mode === 'buffering' && state.status === 'running') state.message = 'Đang tải dữ liệu video...';
            else if (mode === 'playing' && state.status === 'running') state.message = 'Đang phát video — tự chuyển khi phát hết';
            else if (mode === 'paused' && state.status === 'running') state.message = 'Video đang tạm dừng trên trình phát';
            // Keep writes limited to explicit playback changes and a 3-second heartbeat.
            await writeState(id, state);
            return {ok: true, state};
        }
        if (request.action === 'VIDEO_ENDED') {
            if (state.status !== 'running') return { ok: true, state, ignored: true };
            if (!state.queue[state.index] || !sameVideo(request.currentUrl, state.queue[state.index])) {
                return { ok: true, state, ignored: true };
            }
            if (state.nextPending) return { ok: true, state, ignored: true };
            const finishedTitle = state.queue[state.index].title;
            logEvent(state, `Đã phát hết: ${finishedTitle}`);
            state.index += 1;
            state.playback = null;
            if (state.index >= state.queue.length) {
                state.status = 'finished';
                state.message = `Đã phát hết ${state.queue.length} video trong danh sách`;
                logEvent(state, 'Đã phát hết danh sách video');
                await writeState(id, state);
                await broadcast(id, state);
                await notifyFinished(state);
                return { ok: true, state, finished: true, finishedTitle };
            }
            state.message = `Đã xong: ${finishedTitle}. Đang mở video kế tiếp...`;
            state.nextPending = true;
            await writeState(id, state);
            await broadcast(id, state);
            return { ok: true, state, nextUrl: state.queue[state.index].url, finishedTitle };
        }
        if (request.action === 'FRAME_NEXT_NAVIGATION') {
            // A video inside a Coursera iframe may end before the top-frame listener sees it.
            const requested = String(request.nextUrl || '');
            if (state.status !== 'running' || !state.nextPending ||
                !state.queue[state.index] || requested !== state.queue[state.index].url) {
                return { ok: true, state, ignored: true };
            }
            await chrome.tabs.update(id, { url: requested });
            return { ok: true, state };
        }
        if (request.action === 'PAGE_READY') {
            if (state.status === 'running' && state.queue[state.index] &&
                sameVideo(request.currentUrl, state.queue[state.index])) {
                if (state.nextPending) {
                    delete state.nextPending;
                    state.message = 'Đã mở video kế tiếp';
                    logEvent(state, `Chuyển sang: ${state.queue[state.index].title}`);
                    await writeState(id, state);
                }
                return { ok: true, state, play: true };
            }
            return { ok: true, state, play: false };
        }
        throw new Error('Thao tác không được hỗ trợ.');
}

// Only local, trusted code within this same extension's background worker can
// call this function. Never expose it through an externally_connectable API.
// Validation and session-state writes are performed by handleVideoAction.
globalThis.applyVideoCommandFromMonitor = async (action, tabId) => {
    if (!['PAUSE_RUN', 'RESUME_RUN', 'STOP_RUN'].includes(action)) {
        throw new Error('Remote command không được hỗ trợ.');
    }
    if (!Number.isInteger(tabId)) throw new Error('Không tìm thấy tab điều khiển.');
    return handleVideoAction({ action, tabId }, {});
};

chrome.runtime.onMessage.addListener((request, sender, respond) => {
    if (typeof request?.action === 'string' && (request.action.startsWith('PRACTICE_') || request.action.startsWith('MONITOR_'))) return false;
    handleVideoAction(request, sender).then(respond).catch(error => respond({ ok: false, error: error.message }));
    return true;
});

chrome.tabs.onRemoved.addListener(tabId => {
    chrome.storage.session.remove(getKey(tabId)).catch(() => {});
});

// Practice-only AI proxy: never exposes Cloudflare/Groq/Gemini secrets to webpage scripts.
chrome.runtime.onMessage.addListener((request,sender,respond)=>{
  if(request?.action!=='PRACTICE_AI_REQUEST')return false;
  (async()=>{
    if(!sender.tab?.id || !/^https:\/\/([\w-]+\.)*coursera\.org\//i.test(sender.tab.url||''))
      throw Error('Yêu cầu phải đến từ trang Coursera.');
    const config=(await chrome.storage.local.get('aiAssistantConfig')).aiAssistantConfig;
    if(!config?.worker || !config?.token)throw Error('Cần cấu hình Worker URL và token trong tab AI.');
    const url=new URL(config.worker);
    if(url.protocol!=='https:' || url.username || url.password || url.search || url.hash || url.port)
      throw Error('Địa chỉ Worker không hợp lệ.');
    const payload=request.payload||{};
    if(typeof payload.question!=='string'||payload.question.length>12000)throw Error('Câu hỏi không hợp lệ.');
    if(!['single','multiple','text'].includes(payload.type))throw Error('Dạng câu hỏi không hợp lệ.');
    if(!Array.isArray(payload.options)||payload.options.length>25)throw Error('Danh sách phương án không hợp lệ.');
    const response=await fetch(url.origin+'/solve-practice',{method:'POST',
      headers:{Authorization:'Bearer '+config.token,'Content-Type':'application/json'},
      body:JSON.stringify({...payload,mode:config.mode||'auto'})});
    const result=await response.json();
    if(!response.ok||!result.ok)throw Error(result.error||`HTTP ${response.status}`);
    return result;
  })().then(respond).catch(error=>respond({ok:false,error:error.message}));
  return true;
});

// Monitor handler registers after the video/practice listeners.
importScripts('monitor-background.js');
