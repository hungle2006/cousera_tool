'use strict';
// AI assistant reads only text/Images the user explicitly supplies; no automatic quiz harvesting or submission.
const ai$ = id => document.getElementById(id);
let aiBusy = false;
let aiRotation = 0;
const aiFields = ['workerUrl','appToken','aiMode'];
function setTab(ai) {
  ai$('tabVideo').classList.toggle('on',!ai);
  ai$('tabAI').classList.toggle('on',ai);
  ai$('tabVideo').setAttribute('aria-selected',String(!ai));
  ai$('tabAI').setAttribute('aria-selected',String(ai));
  ai$('videoPane').hidden=ai;
  ai$('aiPane').hidden=!ai;
}
ai$('tabVideo').addEventListener('click',()=>setTab(false));
ai$('tabAI').addEventListener('click',()=>setTab(true));
function aiStatus(msg) {ai$('aiStatus').textContent=msg;}
function toDataURL(file) {
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();reader.onload=()=>resolve(reader.result);
    reader.onerror=()=>reject(new Error('Không đọc được ảnh.'));
    reader.readAsDataURL(file);
  });
}
function normalizedWorker() {
  const u=new URL(ai$('workerUrl').value.trim());
  if(u.protocol!=='https:' || u.username || u.password || u.port || u.search || u.hash)
    throw new Error('Worker URL phải là HTTPS và không chứa tài khoản, query hay port.');
  return u.origin;
}
function showAnswer(data) {
  ai$('aiResultPanel').hidden=false;
  ai$('aiCategory').textContent=data.category || '—';
  ai$('aiMeta').textContent=`${data.provider} • ${data.model}\nĐã thử: ${(data.attempted||[]).join(' → ')}`;
  ai$('aiAnswer').textContent=data.answer;
}
ai$('aiRun').addEventListener('click',async()=>{
  if(aiBusy)return;
  let worker;
  try {worker=normalizedWorker();} catch (error) {aiStatus(error.message);return;}
  const token=ai$('appToken').value;
  const question=ai$('aiQuestion').value.trim();
  const file=ai$('aiImage').files?.[0];
  if(!token || (!question && !file)){aiStatus('Cần mã truy cập và câu hỏi hoặc ảnh.');return;}
  if(file && (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size>2*1024*1024)){
    aiStatus('Ảnh phải là JPEG, PNG hoặc WebP và nhỏ hơn 2 MB.');return;
  }
  // Explicit user gesture required for host access; only this user's chosen host is granted.
  let permitted;
  try{permitted=await chrome.permissions.request({origins:[worker+'/*']});}
  catch(error){aiStatus('Không cấp được quyền truy cập Worker: '+error.message);return;}
  if(!permitted){aiStatus('Cần cho phép truy cập URL Worker để gửi câu hỏi.');return;}
  aiBusy=true;ai$('aiRun').disabled=true;aiStatus('Đang phân tích bằng AI...');
  try{
    const imageDataUrl=file?await toDataURL(file):undefined;
    await chrome.storage.local.set({aiAssistantConfig:{worker,token,mode:ai$('aiMode').value},aiAssistantRotation:aiRotation});
    const response=await fetch(worker+'/analyze',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},
      body:JSON.stringify({question,imageDataUrl,mode:ai$('aiMode').value,rotation:aiRotation})});
    const data=await response.json();
    if(!response.ok || !data.ok)throw new Error(data.error || data.errors?.map(x=>`${x.model}: ${x.description}`).join('; ') || `HTTP ${response.status}`);
    aiRotation+=1;
    await chrome.storage.local.set({aiAssistantRotation:aiRotation});
    showAnswer(data); aiStatus(`Đã phân tích với ${data.provider}. Kiểm tra nội dung trước khi sử dụng.`);
  }catch(error){aiStatus(`Lỗi AI: ${error.message}`);}
  finally{aiBusy=false;ai$('aiRun').disabled=false;}
});
ai$('aiClear').addEventListener('click',()=>{
  ai$('aiQuestion').value='';ai$('aiImage').value='';ai$('aiResultPanel').hidden=true;
  aiStatus('Đã xóa câu hỏi và kết quả hiển thị.');
});
(async()=>{
  const data=await chrome.storage.local.get(['aiAssistantConfig','aiAssistantRotation']);
  const c=data.aiAssistantConfig||{};
  ai$('workerUrl').value=c.worker||'https://coursera-ai-control-v5.hungle06-01-01.workers.dev';
  ai$('appToken').value=c.token||'';
  ai$('aiMode').value=c.mode||'auto';
  aiRotation=Number(data.aiAssistantRotation)||0;
})().catch(()=>aiStatus('Không tải được cấu hình đã lưu.'));
