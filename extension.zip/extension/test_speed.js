'use strict';
const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const content = fs.readFileSync(__dirname+'/content.js','utf8');
async function simulate(clamped) {
  let clock = 10_000, loop, contentHandler, attempts = 0, reported=[];
  const callbackMap = new Map();
  const video = {
    isConnected: true, currentTime: 12, duration: 120, paused: false, readyState: 4, ended: false,
    getBoundingClientRect() { return {width: 300,height: 200}; },
    addEventListener(type, cb) { callbackMap.set(type, cb); },
    removeEventListener(type) {callbackMap.delete(type);},
    play() {return Promise.resolve();}, pause() {this.paused=true;},
    get playbackRate() {return this._rate ?? 2;},
    set playbackRate(value) {attempts++;this._rate=clamped?2:value;},
    get defaultPlaybackRate() {return this._defaultRate ?? 1;},
    set defaultPlaybackRate(value){this._defaultRate=value;}
  };
  const runState = {status:'running',index:0,speed:4,playback:null,queue:[{id:'videoid',title:'Video',url:'https://www.coursera.org/learn/course/lecture/videoid/x'}]};
  const chrome={ runtime:{lastError:null,onMessage:{addListener(f){contentHandler=f;}},sendMessage(msg, cb) {if(msg.action==='GET_STATE')cb({ok:true,state:runState}); else if(msg.action==='PAGE_READY') cb({ok:true,state:runState}); else if(msg.action==='PLAYER_STATUS') {reported.push(msg.playback); cb({ok:true,state:runState});} else cb({ok:true,state:runState});}}};
  class ClockDate extends Date {static now(){return clock;}}
  const document = {documentElement:{},querySelectorAll(sel){return sel==='video'?[video]:[];}};
  const window={top:{}};
  const context={globalThis:null,window,document,chrome,URL,Date:ClockDate,WeakSet,WeakMap,console,
    location:{href:'https://www.coursera.org/learn/course/lecture/videoid/x'},
    MutationObserver:class {observe(){}},setInterval(fn){loop=fn;}, setTimeout(){}, clearTimeout(){},fetch(){} };
  context.globalThis=context;
  vm.runInNewContext(content,context);
  assert.equal(typeof loop,'function');
  await Promise.resolve();await Promise.resolve();await Promise.resolve();
  for(let i=0;i<30;i++){clock+=1300; loop(); await Promise.resolve(); }
  assert(reported.length>0, 'should report playback');
  const last=reported.at(-1);
  if(clamped) {
    assert.equal(video.playbackRate,2);
    assert.equal(attempts,12, `must throttle and stop after 12 writes, got ${attempts}`);
    assert.equal(last.rateLimited,true);
    assert.equal(last.rateAttempts,12);
  }else{
    assert.equal(video.playbackRate,4);
    assert(attempts<=2, `should not repeatedly write when speed is retained, got ${attempts}`);
    assert.equal(last.rateLimited,false);
  }
  return {clamped,attempts,rate:video.playbackRate,limited:last.rateLimited};
}
(async()=>{console.log(await simulate(false));console.log(await simulate(true));console.log('PASS: speed control retries, hard cap, actual-rate reporting');})().catch(e=>{console.error(e);process.exitCode=1;});
