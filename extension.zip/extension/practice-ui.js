'use strict';
(() => {
  const $=id=>document.getElementById(id);
  let tabId=null;
  let running=false;
  const prettyTime=x=>{try{return new Date(x).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});}catch{return ''}};
  const isCoursera=x=>/^https:\/\/([\w-]+\.)*coursera\.org\//i.test(x||'');
  async function target(){
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab || !isCoursera(tab.url))throw Error('Mở trang bài tập Coursera trước.');
    tabId=tab.id;return tab;
  }
  async function send(action,args={}){
    await target();
    try {return await chrome.tabs.sendMessage(tabId,{action,...args},{frameId:0});}
    catch(error){
      if(action==='PRACTICE_STATUS')return {ok:false};
      await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},files:['practice.js']});
      return await chrome.tabs.sendMessage(tabId,{action,...args},{frameId:0});
    }
  }
  function status(message){$('practiceMsg').textContent=message;}
  function render(s){
    if(!s)return;
    running=['scanning','solving','submitting'].includes(s.status);
    $('practiceStart').disabled=running;
    $('practiceStop').disabled=!running;
    $('practiceCount').textContent=`${s.filled||0} / ${s.total||0} câu đã điền · ${s.skipped||0} câu bỏ qua`;
    $('practiceFill').style.width=`${s.total?Math.round(s.filled/s.total*100):0}%`;
    $('practiceModel').textContent='AI gần nhất: '+(s.model||'—');
    $('practiceEvents').replaceChildren();
    for(const e of (s.events||[]).slice(-7).reverse()){
      const div=document.createElement('div');
      div.textContent=`${prettyTime(e.time)} · ${e.message}`;
      $('practiceEvents').appendChild(div);
    }
    const statusNames={idle:'Chưa chạy',scanning:'Đang quét câu hỏi...',solving:'AI đang phân tích và điền...',
      submitting:'Đang gửi bài thực hành...',ready:'Đã điền xong (chưa nộp)',finished:s.confirmedSubmit?'Đã gửi và nhận phản hồi hoàn tất':'Đã thử Submit; cần kiểm tra kết quả',error:'Phát sinh lỗi',stopped:'Đã dừng'};
    status(statusNames[s.status]||s.status);
  }
  $('practiceStart').addEventListener('click',async()=>{
    $('practiceStart').disabled=true;
    try {
      const workerInput=$('workerUrl').value.trim();
      const worker=new URL(workerInput);
      if(worker.protocol!=='https:'||worker.username||worker.password||worker.port||worker.search||worker.hash)throw Error('Worker URL phải là HTTPS hợp lệ.');
      if(!$('appToken').value.trim())throw Error('Hãy nhập mã Worker trước.');
      const permitted=await chrome.permissions.request({origins:[worker.origin+'/*']});
      if(!permitted)throw Error('Chưa cấp quyền kết nối Worker.');
      await chrome.storage.local.set({aiAssistantConfig:{worker:worker.origin,
        token:$('appToken').value,mode:$('aiMode').value}});
      const r=await send('PRACTICE_START',{autoSubmit:false});
      if(!r?.ok)throw Error(r?.error||'Không bắt đầu được.');
      render(r.state);
    }catch(error){status('Lỗi: '+error.message);$('practiceStart').disabled=false;}
  });
  $('practiceStop').addEventListener('click',async()=>{
    try{render((await send('PRACTICE_STOP')).state);}catch(error){status(error.message);}
  });
  setInterval(async()=>{
    if($('aiPane').hidden)return;
    try {const r=await send('PRACTICE_STATUS');if(r?.ok)render(r.state);}
    catch(_){/* user may not be on a Coursera page */}
  },1100);
})();
