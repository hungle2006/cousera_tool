'use strict';
// Regression: Chrome MV3 monitor must connect with COURSE (not undefined COUR)
// and report a heartbeat to the Cloudflare Worker.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
(async () => {
  let listener, heartbeatPayload, commandRequests=0;
  const store={
    aiAssistantConfig:{worker:'https://coursera-ai-control-v5.hungle06-01-01.workers.dev',token:'ccc_test_token'},
    autoVideoMonitorConfig:{enabled:true,autoStart:false}
  };
  const chrome={
    storage:{
      local:{get:async keys=>Object.fromEntries(keys.map(k=>[k,store[k]])),set:async o=>Object.assign(store,o)},
      session:{get:async()=>({'videoRun_33':{status:'paused',index:0,queue:[],message:'Tạm dừng'}})}
    },
    tabs:{get:async id=>({id,url:'https://www.coursera.org/learn/test-course/lecture/a123'}),query:async()=>[{id:33,url:'https://www.coursera.org/learn/test-course/lecture/a123'}]},
    runtime:{onMessage:{addListener:fn=>{listener=fn}},onStartup:{addListener:()=>{}},sendMessage:async()=>({ok:true})},
    alarms:{create:async()=>{},onAlarm:{addListener:()=>{}}},
    action:{},
  };
  chrome.tabs.onRemoved={addListener:()=>{}};
  const fetch=async(url,opts={})=>{
    const path=new URL(url).pathname;
    if(path==='/client/heartbeat'){
      heartbeatPayload=JSON.parse(opts.body);
      return {ok:true,json:async()=>({ok:true,account_id:'fbb2a5bf-628d-4187-90dc-b02136dc8294',desired_state:'paused'})};
    }
    if(path==='/client/commands'){
      commandRequests++;
      return {ok:true,json:async()=>({ok:true,commands:[]})};
    }
    throw new Error('Unexpected fetch '+url);
  };
  vm.runInNewContext(fs.readFileSync(__dirname+'/monitor-background.js','utf8'),{
    chrome,fetch,console,URL,AbortController,Date,Map,Set,Number,Error,String,Boolean,setTimeout,clearTimeout,globalThis:{}
  },{filename:'monitor-background.js'});
  assert.equal(typeof listener,'function','monitor message listener missing');
  const reply=await new Promise((resolve,reject)=>{
    const result=listener({action:'MONITOR_CONNECT',tabId:33},{},resolve);
    if(result!==true)reject(Error('Async listener not registered'));
    setTimeout(()=>reject(Error('Monitor connect timed out')),1500);
  });
  assert.deepEqual(JSON.parse(JSON.stringify(reply)),{
    ok:true,accountId:'fbb2a5bf-628d-4187-90dc-b02136dc8294',connected:true
  });
  assert.equal(heartbeatPayload.course_slug,'test-course');
  assert.equal(heartbeatPayload.status,'paused');
  assert.ok(commandRequests>0);
  console.log('PASS MONITOR_CONNECT and heartbeat: course slug + auth path + command polling');
})().catch(e=>{console.error(e);process.exitCode=1});
