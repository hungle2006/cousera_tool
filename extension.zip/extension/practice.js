(() => {
  'use strict';
  if (window !== window.top || window.__courseraPracticeV41) return;
  window.__courseraPracticeV41 = true;

  const selectors = [
    'fieldset', '[data-testid*="question"]', '.rc-FormPartsQuestion',
    '.rc-Question', '[class*="FormPartsQuestion"]', '[role="group"]'
  ].join(',');
  const state = {status:'idle', total:0, filled:0, skipped:0, attemptedSubmit:false,
    confirmedSubmit:false, model:'—', events:[], startedAt:0};
  let cancelled = false, locked = false;
  const log = message => {
    state.events.push({time:new Date().toISOString(),message:String(message).slice(0,260)});
    state.events = state.events.slice(-50);
  };
  const normalize = s => String(s || '').replace(/\s+/g,' ').trim();
  const visible = el => !!el && !!(el.getClientRects().length || (el.offsetParent !== null));
  const text = el => normalize(el?.innerText || el?.textContent || '');
  const isAgreement = el => /agree|honor code|academic integrity|cam kết|đồng ý|i understand|acknowledge/i.test(
    [el.id,el.name,el.closest('label')?.innerText,el.getAttribute('aria-label')].join(' '));
  const isPractice = () => {
    const firstText = normalize(document.body?.innerText || '').slice(0,9000);
    const header = text(document.querySelector('h1,h2,[data-testid*="assignment-title"]'));
    const hasPracticeLabel = /practice assignment|practice quiz|bài tập thực hành|bài luyện tập/i.test(`${header} ${firstText}`);
    const hasGradedLabel = /graded assignment|graded quiz|proctored|timed exam|bài kiểm tra tính điểm|bài thi giám sát/i.test(`${header} ${firstText}`);
    return hasPracticeLabel && !hasGradedLabel;
  };
  function identifyQuestions() {
    const inputs=[...document.querySelectorAll('input[type="radio"], input[type="checkbox"], input[type="text"], textarea')]
      .filter(el => visible(el) && !el.disabled && !isAgreement(el));
    const questions=[];
    const seen=new Map();
    for(const input of inputs) {
      const type=input.matches('textarea, input[type="text"]')?'text':input.type==='checkbox'?'multiple':'single';
      const outer=input.closest(selectors) || input.closest('div[role="group"]') || input.parentElement?.parentElement;
      if(!outer)continue;
      const questionHeader=outer.querySelector('[data-e2e="question-text"], [data-testid*="question-text"], .rc-QuestionText, legend, h3, h4');
      const key=type==='text'?input:(input.name ? `${input.name}::${questions.length ? outer.getAttribute('data-testid') || '' : ''}` : outer);
      // radio grouping should never combine unrelated question containers.
      const groupingKey=(type==='text')?input:(input.name?`${input.name}:${[...document.querySelectorAll(selectors)].indexOf(outer)}`:outer);
      let q=seen.get(groupingKey);
      if(!q){
        q={id:questions.length,type,question:text(questionHeader)||text(outer).slice(0,5000),options:[],input:type==='text'?input:null,el:outer};
        seen.set(groupingKey,q);questions.push(q);
      }
      if(type!=='text'){
        const label=input.closest('label') || input.labels?.[0];
        const labelText=text(label)||normalize(input.getAttribute('aria-label'))||text(input.nextElementSibling);
        q.options.push({index:q.options.length,text:labelText||`Option ${q.options.length+1}`,el:input});
      }
    }
    return questions.filter(q => q.question.length>=5 && (q.type==='text'||q.options.length>=2));
  }
  function setText(input,value){
    const descriptor=Object.getOwnPropertyDescriptor(input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,'value');
    if(descriptor?.set)descriptor.set.call(input,value); else input.value=value;
    input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  }
  function apply(q,answer){
    if(q.type==='text'){
      if(typeof answer.text_answer!=='string'||!answer.text_answer.trim())return false;
      setText(q.input,answer.text_answer.trim());return true;
    }
    const idx=answer.selected_option_indices;
    if(!Array.isArray(idx)||idx.length===0||idx.some(n=>!Number.isInteger(n)||n<0||n>=q.options.length))return false;
    if(q.type==='single'&&idx.length!==1)return false;
    for(const opt of q.options){
      const want=idx.includes(opt.index);
      if(opt.el.checked!==want){
        if(q.type==='single'&&!want)continue;
        opt.el.click();
      }
    }
    return q.options.every(o=>o.el.checked===idx.includes(o.index));
  }
  async function readIllustration(q){
    const img=[...q.el.querySelectorAll('img')].find(img=>img.naturalWidth>40 && img.naturalHeight>40);
    if(!img)return null;
    try{
      const canvas=document.createElement('canvas');
      const scale=Math.min(1,900/Math.max(img.naturalWidth,img.naturalHeight));
      canvas.width=Math.ceil(img.naturalWidth*scale);canvas.height=Math.ceil(img.naturalHeight*scale);
      canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
      const data=canvas.toDataURL('image/jpeg',0.72);
      if(data.length>2_800_000)throw Error('Image too large');
      return data;
    }catch(_){
      log('Không đọc được ảnh do giới hạn CORS; câu có ảnh sẽ bỏ qua để tránh điền sai.');
      return 'UNAVAILABLE';
    }
  }
  const api = async payload=>{
    const response=await chrome.runtime.sendMessage({action:'PRACTICE_AI_REQUEST',payload});
    if(!response?.ok)throw Error(response?.error||'Worker AI không phản hồi.');
    return response;
  };
  async function wait(ms){return new Promise(r=>setTimeout(r,ms));}
  function submitButton(){
    return [...document.querySelectorAll('button, input[type="submit"]')].find(el=>visible(el)&&!el.disabled&&
      /^(submit|submit assignment|submit quiz|nộp bài|gửi bài|gửi bài làm)$/i.test(normalize(el.innerText||el.value||el.getAttribute('aria-label'))));
  }
  function canSubmit(){
    const agreement=[...document.querySelectorAll('input[type="checkbox"]')].find(el=>isAgreement(el)&&!el.checked);
    if(agreement)return {ok:false,why:'Cần người học tự xem và xác nhận Honor Code.'};
    if(!isPractice())return {ok:false,why:'Chỉ bật tự nộp cho Practice Assignment/Practice Quiz, không dùng với bài đánh giá có điểm.'};
    return {ok:true};
  }
  async function autoSubmit(){
    const gate=canSubmit();if(!gate.ok)throw Error(gate.why);
    const btn=submitButton();if(!btn)throw Error('Không tìm thấy nút Submit đang hoạt động.');
    btn.click();state.attemptedSubmit=true;log('Đã nhấn Submit; đang kiểm tra phản hồi từ trang.');
    await wait(900);
    const modal=document.querySelector('[role="dialog"], [aria-modal="true"]');
    if(modal){
      const confirm=[...modal.querySelectorAll('button')].find(el=>!el.disabled&&/^(submit|confirm|yes, submit|nộp bài|xác nhận)$/i.test(text(el)));
      if(confirm){if(!canSubmit().ok)throw Error('Không đủ điều kiện tiếp tục Submit.');confirm.click();log('Đã xác nhận cửa sổ nộp bài.');}
      else log('Có hộp thoại chưa nhận diện; cần kiểm tra thủ công.');
    }
    await wait(900);
    state.confirmedSubmit=/(you passed|submitted|submission received|đã nộp|bài đã nộp|view feedback)/i.test(
      normalize(document.body.innerText).slice(0,12000));
    log(state.confirmedSubmit?'Trang báo đã nhận bài nộp.':'Đã thao tác Submit nhưng chưa xác minh được kết quả trên trang.');
  }
  async function run(autoSubmitEnabled){
    if(locked)throw Error('Một phiên kiểm thử đang chạy.');
    locked=true;cancelled=false;
    Object.assign(state,{status:'scanning',total:0,filled:0,skipped:0,attemptedSubmit:false,confirmedSubmit:false,
      model:'—',events:[],startedAt:Date.now()});
    try {
      if(!isPractice())throw Error('Chế độ tự động chỉ dành cho Practice Assignment/Practice Quiz được nhận diện rõ.');
      const questions=identifyQuestions();if(!questions.length)throw Error('Không thấy câu hỏi trên trang. Mở Resume assignment để vào trang làm bài.');
      state.total=questions.length;state.status='solving';log(`Nhận diện ${questions.length} câu hỏi.`);
      for(const q of questions){
        if(cancelled)throw Error('Đã dừng theo yêu cầu.');
        const imageDataUrl=await readIllustration(q);
        if(imageDataUrl==='UNAVAILABLE'){state.skipped++;continue;}
        const answer=await api({question:q.question,options:q.options.map(x=>x.text),type:q.type,
          imageDataUrl,rotation:q.id});
        state.model=answer.model||'—';
        if(apply(q,answer)){
          state.filled++;log(`Câu ${q.id+1}: đã điền bằng ${answer.provider}/${answer.model}.`);
        } else {state.skipped++;log(`Câu ${q.id+1}: AI không có đáp án hợp lệ.`);}
        await wait(170);
      }
      if(autoSubmitEnabled){
        if(state.filled!==state.total)throw Error(`Chưa điền đủ ${state.total} câu; không tự nộp (${state.skipped} câu cần kiểm tra).`);
        state.status='submitting';await autoSubmit();
      }
      state.status=autoSubmitEnabled?'finished':'ready';
      log(autoSubmitEnabled?'Kết thúc phiên tự nộp Practice.':'Đã điền đáp án; không bật chế độ nộp.');
    }catch(error){state.status=cancelled?'stopped':'error';log(error.message);}
    finally{locked=false;}
  }
  chrome.runtime.onMessage.addListener((req,_sender,respond)=>{
    if(req.action==='PRACTICE_STATUS'){respond({ok:true,state});return;}
    if(req.action==='PRACTICE_STOP'){cancelled=true;respond({ok:true,state});return;}
    if(req.action==='PRACTICE_START'){
      if(locked){respond({ok:false,error:'Đang chạy một phiên.'});return;}
      run(false);respond({ok:true,state});return;
    }
  });
})();
