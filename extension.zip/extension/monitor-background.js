// Coursera Control Center v5.5 — direct MV3 remote command bridge with actual player verification.
// Only controls video in Chrome where this extension is installed and Coursera is open.
'use strict';
(() => {
  const COURSE = /^https:\/\/([a-z\d-]+\.)*coursera\.org\/learn\/([\w-]+)(?:\/|$)/i;
  const lastReport = new Map();
  const busy = new Set();
  // Allow concurrent heartbeat/Connect events to await the same command batch.
  let pollPromise = null;

  function normalizeHost(value) {
    try {
      const u = new URL(value);
      return u.protocol === 'https:' && !u.username && !u.password && !u.search && !u.hash && !u.port ? u.origin : null;
    } catch { return null; }
  }
  async function settings() {
    const r = await chrome.storage.local.get(['aiAssistantConfig', 'autoVideoMonitorConfig']);
    return {
      origin: normalizeHost(r.aiAssistantConfig?.worker),
      token: r.aiAssistantConfig?.token,
      enabled: r.autoVideoMonitorConfig?.enabled === true,
      autoStart: r.autoVideoMonitorConfig?.autoStart === true
    };
  }
  async function api(path, method = 'GET', payload) {
    const cfg = await settings();
    if (!cfg.enabled || !cfg.origin || !cfg.token) throw Error('Chưa bật giám sát hoặc chưa có token tài khoản');
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 12000);
    try {
      const res = await fetch(cfg.origin + path, {
        method,
        headers: { Authorization: 'Bearer ' + cfg.token, ...(payload ? { 'Content-Type': 'application/json' } : {}) },
        body: payload ? JSON.stringify(payload) : undefined,
        signal: ctl.signal,
        cache: 'no-store'
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw Error(data.error || 'HTTP ' + res.status);
      return data;
    } finally { clearTimeout(timer); }
  }
  async function getState(tabId) {
    const entry = await chrome.storage.session.get('videoRun_' + tabId);
    return entry['videoRun_' + tabId] || { status: 'idle', index: 0, queue: [] };
  }
  async function heartbeat(tabId, slug, state, force = false) {
    const ts = Date.now();
    if (!force && ts - (lastReport.get(tabId) || 0) < 12000) return null;
    const total = Math.max(0, Number(state.queue?.length) || 0);
    const completed = Math.min(total, Math.max(0, Number(state.index) || 0));
    const info = await api('/client/heartbeat', 'POST', {
      course_slug: slug,
      status: ['running', 'paused', 'stopped', 'finished', 'error'].includes(state.status) ? state.status : 'idle',
      completed, total,
      message: state.message || 'Extension đang kết nối'
    });
    lastReport.set(tabId, ts);
    await chrome.storage.local.set({ ['monitorInfo_' + tabId]: { state: 'connected', at: Date.now(), accountId: info.account_id } });
    return info;
  }
  async function findControlTab(fallbackTabId) {
    const tabs = await chrome.tabs.query({ url: ['https://*.coursera.org/learn/*', 'https://coursera.org/learn/*'] });
    if (!tabs.length) return null;
    const ranked = await Promise.all(tabs.filter(t => Number.isInteger(t.id) && COURSE.test(t.url || '')).map(async tab => {
      const state = await getState(tab.id);
      // The active video run wins over a background tab or a non-lecture course tab.
      const hasQueue = Array.isArray(state.queue) && state.queue.length > 0;
      const score = (hasQueue ? 100 : 0)
        + (['running', 'paused'].includes(state.status) ? 90 : state.status === 'stopped' ? 30 : 0)
        + (/\/lecture\//.test(tab.url || '') ? 20 : 0)
        + (tab.active ? 8 : 0)
        + (tab.id === fallbackTabId ? 2 : 0);
      return { tab, state, score };
    }));
    ranked.sort((a, b) => b.score - a.score);
    return ranked[0] || null;
  }
  async function mediaControl(tabId, action) {
    if (!chrome.scripting?.executeScript) return { found: false, verified: false, error: 'Không có quyền scripting' };
    try {
      const request = {
        target: { tabId, allFrames: true },
        args: [action],
        func: async (command) => {
          const list = Array.from(document.querySelectorAll('video')).filter(v => v.isConnected);
          if (!list.length) return { found: false, paused: false, playing: false, errors: [] };
          const errors = [];
          if (command === 'pause' || command === 'stop') {
            for (const v of list) { try { v.pause(); } catch (e) { errors.push(String(e.message)); } }
          } else if (command === 'resume') {
            for (const v of list) {
              if (v.ended) { errors.push('Video đã phát hết'); continue; }
              try { await v.play(); } catch (e) { errors.push(String(e.message)); }
            }
          }
          return {
            found: true,
            paused: list.every(v => v.paused),
            playing: list.some(v => !v.paused && !v.ended),
            errors
          };
        }
      };
      let frames;
      try { frames = await chrome.scripting.executeScript(request); }
      catch (allFramesError) {
        // Some third-party frames are not scriptable; retry only the main document.
        frames = await chrome.scripting.executeScript({ ...request, target: { tabId, allFrames: false } });
      }
      const reports = frames.map(x => x.result).filter(Boolean);
      const found = reports.some(x => x.found);
      const verified = action === 'resume' ? reports.some(x => x.playing) : found && reports.filter(x => x.found).every(x => x.paused);
      return { found, verified, error: reports.flatMap(x => x.errors || []).join('; ').slice(0,170) };
    } catch (err) {
      return { found: false, verified: false, error: String(err?.message || err).slice(0,170) };
    }
  }
  async function applyCommand(cmd, fallbackTabId) {
    const target = await findControlTab(fallbackTabId);
    if (!target) return { ok: false, error: 'Không tìm thấy tab khóa học Coursera. Mở trang khóa học trên Chrome.' };
    const { tab, state } = target;
    const hasRun = Array.isArray(state.queue) && state.queue.length > 0;
    const expected = { pause: 'paused', resume: 'running', stop: 'stopped' }[cmd.action];
    if (!expected) return { ok: false, error: 'Lệnh không hợp lệ' };

    // Resume requires a video run initialized locally by the learner.
    if (cmd.action === 'resume' && !hasRun) {
      return { ok: false, error: 'Chưa bấm Bắt đầu trong extension. Hãy mở bài video và khởi chạy danh sách trước.' };
    }
    if (cmd.action === 'resume' && !['paused', 'stopped', 'running'].includes(state.status)) {
      return { ok: false, error: 'Phiên video chưa tạm dừng hoặc đã kết thúc. Hãy mở bài video và bấm Bắt đầu trong extension.' };
    }
    if (cmd.action === 'pause' && !['running', 'paused'].includes(state.status)) {
      return { ok: false, error: 'Chưa có phiên đang chạy để tạm dừng. Bấm Bắt đầu ở extension trước.' };
    }
    if (cmd.action === 'stop' && !['running', 'paused', 'stopped'].includes(state.status)) {
      return { ok: false, error: 'Chưa có phiên video để dừng.' };
    }

    const action = { pause: 'PAUSE_RUN', resume: 'RESUME_RUN', stop: 'STOP_RUN' }[cmd.action];
    // We run in the SAME MV3 service worker as background.js. Sending a
    // runtime message back into our own worker has no receiving endpoint.
    const dispatch = globalThis.applyVideoCommandFromMonitor;
    if (typeof dispatch !== 'function') {
      return { ok: false, error: 'Bộ xử lý trong service worker chưa sẵn sàng. Hãy tải lại tiện ích.' };
    }
    const response = await dispatch(action, tab.id);
    if (!response?.ok) return { ok: false, error: response?.error || 'Background không xử lý được lệnh' };
    const resultingState = response.state?.status;
    if (resultingState !== expected) return { ok: false, error: 'Extension không chuyển sang trạng thái ' + expected + ', hiện tại: ' + (resultingState || 'unknown') };
    const media = await mediaControl(tab.id, cmd.action);
    // Pause/stop are valid automation-control commands even if player is not mounted yet.
    // Do not claim resumed playback if HTML5 video cannot actually play.
    if (cmd.action === 'resume' && !media.verified) {
      await dispatch('PAUSE_RUN', tab.id).catch(() => {});
      return { ok: false, error: media.found ? 'Trình phát từ chối phát tiếp: ' + (media.error || 'Hãy bấm Play trực tiếp trên Coursera') : 'Không tìm thấy video đang mở. Hãy vào bài giảng /lecture/ trước khi nhấn Tiếp tục.' };
    }
    if (cmd.action === 'pause' && media.found && !media.verified) {
      return { ok: false, error: 'Trình phát không xác nhận đã tạm dừng: ' + (media.error || 'Không xác định') };
    }
    return { ok: true, detail: media.found ? 'Đã đồng bộ trạng thái và trình phát' : 'Đã đổi trạng thái của extension; không có video HTML5 đang mở để điều khiển' };
  }
  async function pollCommands(fallbackTabId) {
    if (pollPromise) return pollPromise;
    const task = (async () => {
      const result = await api('/client/commands');
      for (const cmd of result.commands || []) {
        let outcome;
        try { outcome = await applyCommand(cmd, fallbackTabId); }
        catch (err) { outcome = { ok: false, error: String(err?.message || err).slice(0,160) }; }
        await api('/client/ack', 'POST', {
          command_id: cmd.id,
          result: outcome.ok ? 'applied' : 'failed',
          ...(outcome.ok ? (outcome.detail?.startsWith('Đã đổi trạng thái') ? { error: outcome.detail.slice(0,155) } : {}) : { error: outcome.error.slice(0,155) })
        });
      }
    })();
    pollPromise = task;
    try { return await task; }
    finally { if (pollPromise === task) pollPromise = null; }
  }
  async function run(tabId, force = false) {
    if (busy.has(tabId)) return;
    busy.add(tabId);
    try {
      const tab = await chrome.tabs.get(tabId), match = COURSE.exec(tab.url || '');
      if (!match) return;
      const cfg = await settings(); if (!cfg.enabled) return;
      const state = await getState(tabId);
      await heartbeat(tabId, match[2], state, force);
      await pollCommands(tabId);
    } catch (error) {
      await chrome.storage.local.set({ ['monitorInfo_' + tabId]: { state: 'error', at: Date.now(), error: String(error.message).slice(0,160) } }).catch(() => {});
    } finally { busy.delete(tabId); }
  }
  globalThis.publishMonitorState = async (tabId, state) => {
    const cfg = await settings();
    if (!cfg.enabled || !cfg.origin || !cfg.token || !state?.courseSlug) return;
    await run(tabId, false);
  };
  chrome.runtime.onMessage.addListener((req, sender, respond) => {
    if (!['MONITOR_HELLO', 'MONITOR_CONNECT'].includes(req?.action)) return false;
    (async () => {
      const tabId = req.action === 'MONITOR_HELLO' ? sender.tab?.id : req.tabId;
      if (!Number.isInteger(tabId)) throw Error('Không tìm thấy tab Coursera');
      if (req.action === 'MONITOR_HELLO' && sender.frameId !== 0) return { ok: true, ignored: true };
      const tab = await chrome.tabs.get(tabId), m = COURSE.exec(tab.url || '');
      if (!m) throw Error('Hãy mở trang khóa học Coursera');
      const cfg = await settings();
      if (!cfg.enabled || !cfg.origin || !cfg.token) throw Error('Chưa bật kết nối Worker hoặc thiếu token tài khoản');
      const state = await getState(tabId);
      const info = await heartbeat(tabId, m[2], state, true);
      // Auto-start only when explicitly enabled in extension settings.
      if (req.action === 'MONITOR_HELLO' && cfg.autoStart && /\/lecture\//.test(tab.url || '') && (!state.status || state.status === 'idle'))
        await chrome.tabs.sendMessage(tabId, { action: 'AUTO_VIDEO_START' }, { frameId: 0 }).catch(() => {});
      await pollCommands(tabId);
      return { ok: true, accountId: info.account_id, connected: true };
    })().then(respond).catch(e => respond({ ok: false, error: String(e.message) }));
    return true;
  });
  async function sweep() {
    const cfg = await settings(); if (!cfg.enabled) return;
    const target = await findControlTab();
    if (target) await run(target.tab.id, true);
  }
  // Chrome >=120 supports 30-second alarms. Background service workers cannot rely on setInterval.
  chrome.alarms.create('control-heartbeat', { periodInMinutes: 0.5 }).catch(() => {});
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'control-heartbeat') sweep().catch(() => {}); });
  chrome.runtime.onStartup.addListener(() => sweep().catch(() => {}));
  chrome.tabs.onRemoved.addListener(tabId => lastReport.delete(tabId));
})();
